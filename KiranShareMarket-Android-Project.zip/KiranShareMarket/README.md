# Kiran Share Market
Starter Android project for the Kiran Share Market app.

Features in this starter:
- Sensex, Nifty, Bank Nifty
- 1/2/3/5/10/15 minute timeframe UI
- BUY/SELL/WAIT signal cards
- Entry, Stop Loss, Target and Exit fields
- Breakout/Reversal/Order Block/Liquidity/Volume analysis placeholders
- Automatic Trading ON/OFF
- GitHub Actions APK build workflow

Live Angel One SmartAPI/OAuth/TOTP and market-data credentials must be configured securely by the user. Do not commit secrets to GitHub.
