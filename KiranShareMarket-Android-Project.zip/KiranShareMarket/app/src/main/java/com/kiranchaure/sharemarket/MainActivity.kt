package com.kiranchaure.sharemarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KiranShareMarketApp() }
    }
}

@Composable
fun KiranShareMarketApp() {
    var timeframe by remember { mutableStateOf("5 Min") }
    var autoTrading by remember { mutableStateOf(false) }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text("KIRAN SHARE MARKET", style = MaterialTheme.typography.headlineSmall)
                    Text("AI Market Analysis • Breakout • Reversal • Smart Alerts")
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("1 Min", "2 Min", "3 Min", "5 Min", "10 Min", "15 Min").forEach { tf ->
                            FilterChip(selected = timeframe == tf, onClick = { timeframe = tf }, label = { Text(tf) })
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("AI SIGNAL", style = MaterialTheme.typography.titleLarge)
                            Text("BUY / SELL / WAIT")
                            Text("Entry • Stop Loss • Target • Exit")
                            Text("Indicators chart पर नहीं दिखेंगे; उनका combined analysis signal में आएगा.")
                        }
                    }
                }
                item { SignalCard("SENSEX") }
                item { SignalCard("NIFTY") }
                item { SignalCard("BANK NIFTY") }
                item {
                    Card {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Automatic Trading: ${if (autoTrading) "ON" else "OFF"}")
                            Switch(checked = autoTrading, onCheckedChange = { autoTrading = it })
                        }
                    }
                }
                item {
                    Text("Angel One SmartAPI credentials/TOTP इस starter project में शामिल नहीं हैं.")
                }
            }
        }
    }
}

@Composable
fun SignalCard(symbol: String) {
    Card {
        Column(Modifier.padding(16.dp)) {
            Text("$symbol — WAIT", style = MaterialTheme.typography.titleMedium)
            Text("Entry: —   SL: —   Target: —")
            Text("Breakout + Reversal + Order Block + Liquidity + Volume analysis pending")
        }
    }
}
